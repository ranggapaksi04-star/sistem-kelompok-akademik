<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "kelompok_akademik"
);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>