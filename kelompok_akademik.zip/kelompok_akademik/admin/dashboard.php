<?php
session_start();
include "../koneksi.php";

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit;
}

if($_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit;
}
?>
<?php

$jumlah_mahasiswa = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM mahasiswa")
);

$jumlah_kelompok = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM kelompok")
);

$jumlah_matakuliah = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM mata_kuliah")
);

$jumlah_tugas = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM tugas_kelompok")
);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">

    <h1 class="mb-3">📚 Sistem Kelompok Akademik</h1>

    <h2>Dashboard Admin</h2>

<div class="alert alert-primary mt-3">
    Selamat datang, <b><?php echo $_SESSION['username']; ?></b>
</div>

<hr>

<h3>Statistik Data</h3>

    <div class="row">

        <div class="col-md-3 mb-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h5>Mahasiswa</h5>
                    <h2><?php echo $jumlah_mahasiswa; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h5>Kelompok</h5>
                    <h2><?php echo $jumlah_kelompok; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h5>Mata Kuliah</h5>
                    <h2><?php echo $jumlah_matakuliah; ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card text-center shadow">
                <div class="card-body">
                    <h5>Tugas</h5>
                    <h2><?php echo $jumlah_tugas; ?></h2>
                </div>
            </div>
        </div>

    </div>

    <hr>

    <div class="d-grid gap-2 mt-4">

        <a href="../mahasiswa/index.php" class="btn btn-primary">
            Data Mahasiswa
        </a>

        <a href="../kelompok/index.php" class="btn btn-success">
            Data Kelompok
        </a>

        <a href="../mata_kuliah/index.php" class="btn btn-warning">
            Data Mata Kuliah
        </a>

        <a href="../tugas_kelompok/index.php" class="btn btn-info">
            Data Tugas Kelompok
        </a>

        <a href="../logout.php" class="btn btn-danger">
            Logout
        </a>

    </div>

</div>

</body>
</html>