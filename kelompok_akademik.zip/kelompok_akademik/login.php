<?php
session_start();
include "koneksi.php";

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query(
        $conn,
        "SELECT * FROM user
        WHERE username='$username'
        AND password='$password'"
    );

    $data = mysqli_fetch_assoc($query);

    if($data){

        $_SESSION['username'] = $data['username'];
        $_SESSION['role'] = $data['role'];

        if($data['role']=="admin"){
            header("Location: admin/dashboard.php");
        }else{
            header("Location: mahasiswa_role/dashboard.php");
        }

        exit;

    }else{
        $error = "Username atau Password Salah";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Sistem Kelompok Akademik</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="login-container">

    <h1>Login</h1>

    <h3 align="center">
        Sistem Kelompok Akademik
    </h3>

    <?php
    if(isset($error)){
        echo "<p style='color:red;text-align:center;'>$error</p>";
    }
    ?>

    <form method="POST">

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>

        <button type="submit" name="login" class="btn-login">
            Login
        </button>

    </form>

</div>

</body>
</html>