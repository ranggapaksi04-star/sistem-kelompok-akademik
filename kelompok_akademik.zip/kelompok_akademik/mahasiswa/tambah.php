<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim      = $_POST['nim'];
    $nama     = $_POST['nama'];
    $email    = $_POST['email'];
    $jurusan  = $_POST['jurusan'];
    $semester = $_POST['semester'];

    mysqli_query($conn, "INSERT INTO mahasiswa (nim, nama, email, jurusan, semester)
                         VALUES ('$nim','$nama','$email','$jurusan','$semester')");

header("Location: http://localhost/kelompok_akademik/admin/dashboard.php");
exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Tambah Mahasiswa</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Tambah Mahasiswa Baru</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">NIM</label>
      <input type="text" name="nim" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nama Lengkap</label>
      <input type="text" name="nama" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Jurusan</label>
      <input type="text" name="jurusan" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Semester</label>
      <input type="number" name="semester" class="form-control" min="1" max="14">
    </div>
    <button type="submit" class="btn btn-primary w-100">💾 Simpan</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>