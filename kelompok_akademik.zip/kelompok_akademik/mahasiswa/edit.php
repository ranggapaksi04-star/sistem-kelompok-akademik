<?php
include '../koneksi.php';
$id  = $_GET['id'];
$mhs = mysqli_fetch_assoc(mysqli_query($conn,
       "SELECT * FROM mahasiswa WHERE id_mahasiswa = $id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim      = $_POST['nim'];
    $nama     = $_POST['nama'];
    $email    = $_POST['email'];
    $jurusan  = $_POST['jurusan'];
    $semester = $_POST['semester'];

    mysqli_query($conn, "UPDATE mahasiswa SET
        nim='$nim', nama='$nama', email='$email',
        jurusan='$jurusan', semester='$semester'
        WHERE id_mahasiswa = $id");
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Edit Mahasiswa</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Edit Data Mahasiswa</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">NIM</label>
      <input type="text" name="nim" class="form-control" value="<?= $mhs['nim'] ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nama Lengkap</label>
      <input type="text" name="nama" class="form-control" value="<?= $mhs['nama'] ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" value="<?= $mhs['email'] ?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Jurusan</label>
      <input type="text" name="jurusan" class="form-control" value="<?= $mhs['jurusan'] ?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Semester</label>
      <input type="number" name="semester" class="form-control" value="<?= $mhs['semester'] ?>">
    </div>
    <button type="submit" class="btn btn-warning w-100">✏️ Update</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>