<?php include '../koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Mahasiswa</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4>👤 Daftar Mahasiswa</h4>
  <div class="mb-3">
    <a href="tambah.php" class="btn btn-primary">+ Tambah Mahasiswa</a>
    <a href="../admin/dashboard.php" class="btn btn-secondary">← Kembali</a>
  </div>
  <table class="table table-bordered table-hover bg-white">
    <thead class="table-dark">
      <tr>
        <th>No</th><th>NIM</th><th>Nama</th>
        <th>Jurusan</th><th>Semester</th><th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php
    $result = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY id_mahasiswa");
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
    ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['nim'] ?></td>
        <td><?= $row['nama'] ?></td>
        <td><?= $row['jurusan'] ?></td>
        <td><?= $row['semester'] ?></td>
        <td>
          <a href="edit.php?id=<?= $row['id_mahasiswa'] ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="hapus.php?id=<?= $row['id_mahasiswa'] ?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>