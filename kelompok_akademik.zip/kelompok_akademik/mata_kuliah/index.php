<?php include '../koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Data Mata Kuliah</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4>📚 Daftar Mata Kuliah</h4>
  <div class="mb-3">
    <a href="tambah.php" class="btn btn-warning">+ Tambah Mata Kuliah</a>
<a href="../admin/dashboard.php" class="btn btn-secondary">← Kembali</a>  </div>
  <table class="table table-bordered table-hover bg-white">
    <thead class="table-dark">
      <tr><th>No</th><th>Kode</th><th>Nama Mata Kuliah</th><th>SKS</th><th>Semester</th><th>Aksi</th></tr>
    </thead>
    <tbody>
    <?php
    $result = mysqli_query($conn, "SELECT * FROM mata_kuliah ORDER BY id_matkul");
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
    ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['kode_matkul'] ?></td>
        <td><?= $row['nama_matkul'] ?></td>
        <td><?= $row['sks'] ?></td>
        <td><?= $row['semester'] ?></td>
        <td>
          <a href="edit.php?id=<?= $row['id_matkul'] ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="hapus.php?id=<?= $row['id_matkul'] ?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>