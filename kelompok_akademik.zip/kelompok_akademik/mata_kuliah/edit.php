<?php
include '../koneksi.php';
$id  = $_GET['id'];
$mk  = mysqli_fetch_assoc(mysqli_query($conn,
       "SELECT * FROM mata_kuliah WHERE id_matkul = $id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode = $_POST['kode_matkul'];
    $nama = $_POST['nama_matkul'];
    $sks  = $_POST['sks'];
    $sem  = $_POST['semester'];
    mysqli_query($conn, "UPDATE mata_kuliah SET
        kode_matkul='$kode', nama_matkul='$nama',
        sks='$sks', semester='$sem'
        WHERE id_matkul = $id");
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Edit Mata Kuliah</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Edit Mata Kuliah</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Kode Mata Kuliah</label>
      <input type="text" name="kode_matkul" class="form-control" value="<?= $mk['kode_matkul'] ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nama Mata Kuliah</label>
      <input type="text" name="nama_matkul" class="form-control" value="<?= $mk['nama_matkul'] ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">SKS</label>
      <input type="number" name="sks" class="form-control" value="<?= $mk['sks'] ?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Semester</label>
      <input type="number" name="semester" class="form-control" value="<?= $mk['semester'] ?>">
    </div>
    <button type="submit" class="btn btn-warning w-100">✏️ Update</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>