<?php
include '../koneksi.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode = $_POST['kode_matkul'];
    $nama = $_POST['nama_matkul'];
    $sks  = $_POST['sks'];
    $sem  = $_POST['semester'];
    mysqli_query($conn, "INSERT INTO mata_kuliah (kode_matkul, nama_matkul, sks, semester)
                         VALUES ('$kode','$nama','$sks','$sem')");
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Tambah Mata Kuliah</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Tambah Mata Kuliah</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Kode Mata Kuliah</label>
      <input type="text" name="kode_matkul" class="form-control" placeholder="contoh: BD101" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nama Mata Kuliah</label>
      <input type="text" name="nama_matkul" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">SKS</label>
      <input type="number" name="sks" class="form-control" min="1" max="6">
    </div>
    <div class="mb-3">
      <label class="form-label">Semester</label>
      <input type="number" name="semester" class="form-control" min="1" max="14">
    </div>
    <button type="submit" class="btn btn-warning w-100">💾 Simpan</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>