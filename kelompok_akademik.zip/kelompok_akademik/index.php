<div class="container mt-5">
    <h1 class="text-center mb-4">📚 Sistem Kelompok Akademik</h1>

    <div class="row">
        <div class="col-md-3">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>👤 Mahasiswa</h5>
                    <a href="mahasiswa/index.php" class="btn btn-primary">
                        Buka
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card shadow">
                <div class="card-body text-center">
                    <h5>👥 Kelompok</h5>
                    <a href="kelompok/index.php" class="btn btn-success">
                        Buka
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>