<?php
session_start();

if(!isset($_SESSION['role'])){
    header("Location: ../login.php");
    exit;
}

if($_SESSION['role'] != 'mahasiswa'){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Mahasiswa</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<h1>Sistem Kelompok Akademik</h1>

<hr>

<h2>Dashboard Mahasiswa</h2>

<p>
Selamat datang,
<b><?php echo $_SESSION['username']; ?></b>
</p>

<hr>

<div class="menu">
    <a href="../kelompok/index.php">
        Lihat Kelompok
    </a>
</div>

<div class="menu">
    <a href="../tugas_kelompok/index.php">
        Lihat Tugas
    </a>
</div>

<div class="menu">
    <a href="../logout.php">
        Logout
    </a>
</div>

</body>
</html>