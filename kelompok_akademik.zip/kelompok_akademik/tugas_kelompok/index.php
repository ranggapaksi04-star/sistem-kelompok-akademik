<?php include '../koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Tugas Kelompok</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4>📝 Daftar Tugas Kelompok</h4>
  <div class="mb-3">
    <a href="tambah.php" class="btn btn-danger">+ Tambah Tugas</a>
    <a href="../admin/dashboard.php" class="btn btn-secondary">← Kembali</a>
  </div>
  <table class="table table-bordered table-hover bg-white">
    <thead class="table-dark">
      <tr><th>No</th><th>Kelompok</th><th>Mata Kuliah</th><th>Judul Tugas</th><th>Tenggat</th><th>Status</th><th>Aksi</th></tr>
    </thead>
    <tbody>
    <?php
    $result = mysqli_query($conn,
      "SELECT tk.*, k.nama_kelompok, m.nama_matkul
       FROM tugas_kelompok tk
       JOIN kelompok k ON tk.id_kelompok = k.id_kelompok
       JOIN mata_kuliah m ON tk.id_matkul = m.id_matkul
       ORDER BY tk.id_tugas");
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
      $badge = $row['status'] == 'selesai' ? 'success' : ($row['status'] == 'proses' ? 'warning' : 'secondary');
    ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= $row['nama_kelompok'] ?></td>
        <td><?= $row['nama_matkul'] ?></td>
        <td><?= $row['judul_tugas'] ?></td>
        <td><?= $row['tenggat_waktu'] ?></td>
        <td><span class="badge bg-<?= $badge ?>"><?= $row['status'] ?></span></td>
        <td>
          <a href="edit.php?id=<?= $row['id_tugas'] ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="hapus.php?id=<?= $row['id_tugas'] ?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>