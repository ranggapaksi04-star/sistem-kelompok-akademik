<?php
include '../koneksi.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_kelompok = $_POST['id_kelompok'];
    $id_matkul   = $_POST['id_matkul'];
    $judul       = $_POST['judul_tugas'];
    $desk        = $_POST['deskripsi'];
    $tenggat     = $_POST['tenggat_waktu'];
    $status      = $_POST['status'];
    mysqli_query($conn,
      "INSERT INTO tugas_kelompok (id_kelompok, id_matkul, judul_tugas, deskripsi, tenggat_waktu, status)
       VALUES ('$id_kelompok','$id_matkul','$judul','$desk','$tenggat','$status')");
    header("Location: index.php"); exit;
}
$kelompok = mysqli_query($conn, "SELECT * FROM kelompok");
$matkul   = mysqli_query($conn, "SELECT * FROM mata_kuliah");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Tambah Tugas</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Tambah Tugas Kelompok</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Kelompok</label>
      <select name="id_kelompok" class="form-select" required>
        <option value="">-- Pilih Kelompok --</option>
        <?php while ($k = mysqli_fetch_assoc($kelompok)) { ?>
          <option value="<?= $k['id_kelompok'] ?>"><?= $k['nama_kelompok'] ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Mata Kuliah</label>
      <select name="id_matkul" class="form-select" required>
        <option value="">-- Pilih Mata Kuliah --</option>
        <?php while ($m = mysqli_fetch_assoc($matkul)) { ?>
          <option value="<?= $m['id_matkul'] ?>"><?= $m['nama_matkul'] ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Judul Tugas</label>
      <input type="text" name="judul_tugas" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Deskripsi</label>
      <textarea name="deskripsi" class="form-control" rows="3"></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Tenggat Waktu</label>
      <input type="date" name="tenggat_waktu" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="belum">Belum</option>
        <option value="proses">Proses</option>
        <option value="selesai">Selesai</option>
      </select>
    </div>
    <button type="submit" class="btn btn-danger w-100">💾 Simpan</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>