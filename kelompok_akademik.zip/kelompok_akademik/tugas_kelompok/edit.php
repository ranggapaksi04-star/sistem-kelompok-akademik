<?php
include '../koneksi.php';
$id   = $_GET['id'];
$tugas = mysqli_fetch_assoc(mysqli_query($conn,
         "SELECT * FROM tugas_kelompok WHERE id_tugas = $id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_kelompok = $_POST['id_kelompok'];
    $id_matkul   = $_POST['id_matkul'];
    $judul       = $_POST['judul_tugas'];
    $desk        = $_POST['deskripsi'];
    $tenggat     = $_POST['tenggat_waktu'];
    $status      = $_POST['status'];
    mysqli_query($conn,
      "UPDATE tugas_kelompok SET
       id_kelompok='$id_kelompok', id_matkul='$id_matkul',
       judul_tugas='$judul', deskripsi='$desk',
       tenggat_waktu='$tenggat', status='$status'
       WHERE id_tugas = $id");
    header("Location: index.php"); exit;
}
$kelompok = mysqli_query($conn, "SELECT * FROM kelompok");
$matkul   = mysqli_query($conn, "SELECT * FROM mata_kuliah");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Edit Tugas</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Edit Tugas Kelompok</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Kelompok</label>
      <select name="id_kelompok" class="form-select">
        <?php while ($k = mysqli_fetch_assoc($kelompok)) { ?>
          <option value="<?= $k['id_kelompok'] ?>"
            <?= $k['id_kelompok'] == $tugas['id_kelompok'] ? 'selected' : '' ?>>
            <?= $k['nama_kelompok'] ?>
          </option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Mata Kuliah</label>
      <select name="id_matkul" class="form-select">
        <?php while ($m = mysqli_fetch_assoc($matkul)) { ?>
          <option value="<?= $m['id_matkul'] ?>"
            <?= $m['id_matkul'] == $tugas['id_matkul'] ? 'selected' : '' ?>>
            <?= $m['nama_matkul'] ?>
          </option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Judul Tugas</label>
      <input type="text" name="judul_tugas" class="form-control" value="<?= $tugas['judul_tugas'] ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Deskripsi</label>
      <textarea name="deskripsi" class="form-control" rows="3"><?= $tugas['deskripsi'] ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Tenggat Waktu</label>
      <input type="date" name="tenggat_waktu" class="form-control" value="<?= $tugas['tenggat_waktu'] ?>">
    </div>
    <div class="mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="belum" <?= $tugas['status']=='belum' ? 'selected':'' ?>>Belum</option>
        <option value="proses" <?= $tugas['status']=='proses' ? 'selected':'' ?>>Proses</option>
        <option value="selesai" <?= $tugas['status']=='selesai' ? 'selected':'' ?>>Selesai</option>
      </select>
    </div>
    <button type="submit" class="btn btn-warning w-100">✏️ Update</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>