<?php
include '../koneksi.php';
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM tugas_kelompok WHERE id_tugas = $id");
header("Location: index.php"); exit;
?>