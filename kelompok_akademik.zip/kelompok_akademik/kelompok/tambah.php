<?php
include '../koneksi.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_kelompok'];
    $desk = $_POST['deskripsi'];
    $maks = $_POST['jumlah_maks'];
    mysqli_query($conn, "INSERT INTO kelompok (nama_kelompok, deskripsi, jumlah_maks)
                         VALUES ('$nama','$desk','$maks')");
    header("Location: index.php"); exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Buat Kelompok</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5 class="mb-4">Buat Kelompok Baru</h5>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Nama Kelompok</label>
      <input type="text" name="nama_kelompok" class="form-control" placeholder="contoh: Kelompok 1" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Deskripsi</label>
      <textarea name="deskripsi" class="form-control" rows="3"></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Jumlah Maks Anggota</label>
      <input type="number" name="jumlah_maks" class="form-control" value="5" min="1">
    </div>
    <button type="submit" class="btn btn-success w-100">✅ Buat Kelompok</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
</div>
</body>
</html>