<?php include '../koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Data Kelompok</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4">
  <h4>👥 Daftar Kelompok</h4>
  <div class="mb-3">
    <a href="tambah.php" class="btn btn-success">+ Buat Kelompok</a>
    <a href="../admin/dashboard.php" class="btn btn-secondary">← Kembali</a>
  </div>
  <?php
  $kelompok = mysqli_query($conn, "SELECT * FROM kelompok");
  while ($k = mysqli_fetch_assoc($kelompok)) {
  ?>
  <div class="card mb-3 shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
      <strong>📌 <?= $k['nama_kelompok'] ?></strong>
      <div>
        <a href="assign.php?id=<?= $k['id_kelompok'] ?>" class="btn btn-primary btn-sm">+ Anggota</a>
        <a href="hapus.php?id=<?= $k['id_kelompok'] ?>" class="btn btn-danger btn-sm"
           onclick="return confirm('Hapus kelompok?')">Hapus</a>
      </div>
    </div>
    <div class="card-body">
      <p class="text-muted"><?= $k['deskripsi'] ?></p>
      <strong>Anggota:</strong>
      <ul class="mt-2">
      <?php
      $id_k = $k['id_kelompok'];
      $angg = mysqli_query($conn,
        "SELECT m.nama, m.nim, ak.peran
         FROM anggota_kelompok ak
         JOIN mahasiswa m ON ak.id_mahasiswa = m.id_mahasiswa
         WHERE ak.id_kelompok = $id_k");
      if (mysqli_num_rows($angg) == 0) echo "<li class='text-muted'>Belum ada anggota</li>";
      while ($a = mysqli_fetch_assoc($angg)) {
      ?>
        <li><?= $a['nim'] ?> — <?= $a['nama'] ?>
          <span class="badge bg-secondary"><?= $a['peran'] ?></span>
        </li>
      <?php } ?>
      </ul>
    </div>
  </div>
  <?php } ?>
</div>
</body>
</html>