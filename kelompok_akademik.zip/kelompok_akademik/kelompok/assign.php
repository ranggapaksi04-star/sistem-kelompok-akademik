<?php
include '../koneksi.php';
$id_kelompok = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_mhs = $_POST['id_mahasiswa'];
    $peran  = $_POST['peran'];
    mysqli_query($conn, "INSERT INTO anggota_kelompok (id_mahasiswa, id_kelompok, peran)
                         VALUES ('$id_mhs','$id_kelompok','$peran')");
    header("Location: index.php"); exit;
}

$mhs = mysqli_query($conn,
  "SELECT * FROM mahasiswa WHERE id_mahasiswa NOT IN (
     SELECT id_mahasiswa FROM anggota_kelompok WHERE id_kelompok = $id_kelompok
   )");
$kel = mysqli_fetch_assoc(mysqli_query($conn,
  "SELECT nama_kelompok FROM kelompok WHERE id_kelompok = $id_kelompok"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"><title>Tambah Anggota</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-4" style="max-width:500px">
  <h5>Tambah Anggota</h5>
  <p class="text-muted mb-4">Kelompok: <strong><?= $kel['nama_kelompok'] ?></strong></p>
  <?php if (mysqli_num_rows($mhs) == 0) { ?>
    <div class="alert alert-warning">Semua mahasiswa sudah tergabung dalam kelompok ini.</div>
    <a href="index.php" class="btn btn-secondary">← Kembali</a>
  <?php } else { ?>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Pilih Mahasiswa</label>
      <select name="id_mahasiswa" class="form-select" required>
        <option value="">-- Pilih Mahasiswa --</option>
        <?php while ($m = mysqli_fetch_assoc($mhs)) { ?>
          <option value="<?= $m['id_mahasiswa'] ?>"><?= $m['nim'] ?> — <?= $m['nama'] ?></option>
        <?php } ?>
      </select>
    </div>
    <div class="mb-3">
      <label class="form-label">Peran</label>
      <select name="peran" class="form-select">
        <option value="anggota">Anggota</option>
        <option value="ketua">Ketua</option>
        <option value="wakil ketua">Wakil Ketua</option>
        <option value="sekretaris">Sekretaris</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary w-100">➕ Tambahkan</button>
    <a href="index.php" class="btn btn-secondary w-100 mt-2">Batal</a>
  </form>
  <?php } ?>
</div>
</body>
</html>