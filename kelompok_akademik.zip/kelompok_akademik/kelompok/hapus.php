<?php
include '../koneksi.php';
$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM anggota_kelompok WHERE id_kelompok = $id");
mysqli_query($conn, "DELETE FROM kelompok WHERE id_kelompok = $id");
header("Location: index.php"); exit;
?>